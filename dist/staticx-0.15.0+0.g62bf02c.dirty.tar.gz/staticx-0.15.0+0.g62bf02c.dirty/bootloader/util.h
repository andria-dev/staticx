#ifndef UTIL_H
#define UTIL_H

int remove_tree(const char *pathname);

#endif /* UTIL_H */
