StaticX
=======

Bundle dynamic executables with their library dependencies so they can be run
anywhere, just like a static executable.

.. toctree::
   :maxdepth: 1
   :glob:

   introduction
   installation
   usage
   troubleshooting
   rpath
   changelog
