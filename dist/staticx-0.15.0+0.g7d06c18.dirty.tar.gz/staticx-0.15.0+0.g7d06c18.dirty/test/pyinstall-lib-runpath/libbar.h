#ifndef LIBBAR_DOT_H
#define LIBBAR_DOT_H

int bar(void);

#endif /* LIBBAR_DOT_H */
