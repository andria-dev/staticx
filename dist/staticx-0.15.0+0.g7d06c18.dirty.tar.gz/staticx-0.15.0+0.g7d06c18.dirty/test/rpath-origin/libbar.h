#ifndef LIBBAR_DOT_H
#define LIBBAR_DOT_H

void bar_nop(void);

#endif /* LIBBAR_DOT_H */
